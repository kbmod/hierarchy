"""One directory per bot. Nothing is shared across bots."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from hierarchy.models import Bot


class Store:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def bot_dir(self, bot_id: str) -> Path:
        path = self.root / "bots" / bot_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    def write_bot(self, bot: Bot) -> None:
        _write_json(
            self.bot_dir(bot.id) / "identity.json",
            {
                "id": bot.id,
                "name": bot.name,
                "job": bot.job,
                "description": bot.description,
                "reports_to": bot.reports_to,
                "provider": bot.provider,
                "model": bot.model,
            },
        )
        if not (self.bot_dir(bot.id) / "instructions.md").exists():
            (self.bot_dir(bot.id) / "instructions.md").write_text(
                f"You are {bot.name}, {bot.job}.\n\n{bot.description}\n",
                encoding="utf-8",
            )

    def list_bots(self) -> list[Bot]:
        root = self.root / "bots"
        if not root.exists():
            return []
        bots: list[Bot] = []
        for child in sorted(root.iterdir()):
            identity = child / "identity.json"
            if identity.exists():
                bots.append(_bot_from_dict(_read_json(identity)))
        return bots

    def get(self, bot_id: str) -> Bot:
        path = self.root / "bots" / bot_id / "identity.json"
        if not path.exists():
            raise KeyError(bot_id)
        return _bot_from_dict(_read_json(path))

    def find_by_name(self, name: str) -> Bot | None:
        want = name.strip().lower()
        for bot in self.list_bots():
            if bot.name.lower() == want:
                return bot
        return None

    def instructions(self, bot_id: str) -> str:
        path = self.bot_dir(bot_id) / "instructions.md"
        return path.read_text(encoding="utf-8") if path.exists() else ""

    def write_instructions(self, bot_id: str, text: str) -> None:
        self.get(bot_id)
        (self.bot_dir(bot_id) / "instructions.md").write_text(text, encoding="utf-8")

    def codex_state(self, bot_id: str) -> dict[str, Any]:
        """Return the non-secret Codex session metadata for a bot.

        A missing or unreadable session is treated as a fresh session.  The
        next successful turn replaces it atomically, so a partial write can
        never leave the runtime with a half-valid JSON document.
        """
        self.get(bot_id)
        path = self.bot_dir(bot_id) / "codex.json"
        if not path.exists():
            return {}
        try:
            data = _read_json(path)
        except (OSError, ValueError, TypeError):
            return {}
        return data if isinstance(data, dict) else {}

    def write_codex_state(self, bot_id: str, state: dict[str, Any]) -> None:
        """Persist only non-secret, per-bot Codex session metadata."""
        self.get(bot_id)
        if not isinstance(state, dict):
            raise TypeError("Codex state must be a JSON object")
        allowed = {"thread_id", "turn_id", "cwd", "model", "provider"}
        clean = {key: value for key, value in state.items() if key in allowed and value is not None}
        _write_json_atomic(self.bot_dir(bot_id) / "codex.json", clean, mode=0o600)

    def append(self, bot_id: str, role: str, content: str) -> None:
        path = self.bot_dir(bot_id) / "history.jsonl"
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"role": role, "content": content}) + "\n")

    def history(self, bot_id: str) -> list[dict[str, str]]:
        path = self.bot_dir(bot_id) / "history.jsonl"
        if not path.exists():
            return []
        rows: list[dict[str, str]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rows.append(json.loads(line))
        return rows

    def preview(self, bot_id: str) -> str:
        history = self.history(bot_id)
        if not history:
            return self.get(bot_id).description
        return history[-1]["content"]


def _bot_from_dict(data: dict[str, Any]) -> Bot:
    provider = data.get("provider") or None
    model = data.get("model") or None
    if isinstance(provider, str):
        provider = provider.strip() or None
    else:
        provider = None
    if isinstance(model, str):
        model = model.strip() or None
    else:
        model = None
    return Bot(
        id=data["id"],
        name=data["name"],
        job=data["job"],
        description=data["description"],
        reports_to=data.get("reports_to"),
        provider=provider,
        model=model,
    )


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _write_json_atomic(path: Path, payload: Any, *, mode: int | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary = handle.name
            handle.write(json.dumps(payload, indent=2))
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        if mode is not None:
            os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))
